# Changelog

## sasaOS Beta v3 — initial GitHub publication

- Published the browser-based sasaOS Beta prototype.
- Combined desktop UI, app/window management, status UI, settings, and simulated power screens.
- Added a browser-oriented interface for trying web navigation.
- Documented the current prototype limitations and planned ESP32 integration.

### Notes

This is a prototype release, not a numbered stable release. Hardware features and status values may be simulated.
