# sasaOS Beta

**sasaOS** is an experimental desktop-style interface project exploring a lightweight OS experience for ESP32-class hardware.

> **Current status:** Browser-based prototype. This repository does not yet contain a complete, bootable ESP32 operating system. The HTML prototype runs in a desktop browser such as Chrome.

## Features in the prototype

- Desktop-style interface and taskbar
- App/window management demo
- Settings and dark-mode UI
- Notes and browser-local persistence where implemented
- Simulated startup and power-management screens
- Browser-launching shortcuts / web navigation UI

Some values and hardware features are simulations. Wi-Fi signal strength, battery percentage, real ESP32 communication, and hardware power control are not implemented as real device readings/actions in this prototype.

## Run locally

1. Download or clone this repository.
2. Open `index.html` in Chrome or another modern browser.
3. Try the desktop icons, Start menu, settings, and browser controls.

Some websites prevent embedding in another page. When that happens, open the website in a separate browser tab. The prototype does not replace Chrome's browser engine.

## Hardware direction

- Target board: ESP32 D1 R32 (planned / in development)
- Power plan: USB power from an external power bank
- Development environment: Chromebook / browser-first workflow

Hardware support is still under development. Do not treat this prototype as firmware for flashing to the ESP32.

## Roadmap

- [ ] Test and refine the HTML prototype
- [ ] Separate UI modules and document the app architecture
- [ ] Define a communication format between the UI and ESP32
- [ ] Add real Wi-Fi status and RSSI reporting on the ESP32
- [ ] Investigate feasible browser integration and hardware limits
- [ ] Add hardware-specific power reporting where supported

## Contributing and feedback

Issues and suggestions are welcome. Please include steps to reproduce bugs and describe your browser/device environment.

## License

No license has been selected yet. Until a license is added, assume standard copyright applies; public visibility alone does not grant permission to reuse or redistribute the code.
